from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.common.by import By
import time
import os #para reportes-capturas

#para repositorio de capturas
diractual= os.path.dirname(os.path.abspath(__file__))
capturasdir= os.path.join(diractual,'capturasreporte')
if not os.path.exists(capturasdir):os.makedirs(capturasdir) #para crear carpeta si no existe ya
#función para captura pantallas
def capturarpantalla(driver, nombrearchivo):
    try:
        rutaarchivo=os.path.join(capturasdir,nombrearchivo)
        driver.save_screenshot(rutaarchivo)
        print(f"Captura guardada: {rutaarchivo}")
    except Exception as e:
        print(f"Error al guardar la captura {nombrearchivo}:{e}")

#config WebDriver automatico con Selenium Manager
options = ChromeOptions()
options.add_argument("--start-maximized") #navegador en pantalla completa
service = ChromeService() #declaro service
driver = webdriver.Chrome(service=service, options=options) #declaro driver con service y options importados

try:
    #Abrir pagina provista para el ejercicio, en este caso demoblaze
    driver.get("https://www.demoblaze.com")
    time.sleep(4) #tiempo espera 4 segs en este caso
    #tomar captura antes de llenar el carrito
    capturarpantalla(driver,'inicio.png') #capturar la pantalla inicial
    #llenando carrito
    #prod1 - nota: esperar luego de cada acción 3 segundos (suficiente)
    driver.find_element(By.LINK_TEXT, "Samsung galaxy s6").click() #se hace click en el enlace del producto
    time.sleep(3)
    driver.find_element(By.LINK_TEXT, "Add to cart").click() #se hace click en "Add to cart" para llevar el S6 al carrito
    time.sleep(3)
    driver.switch_to.alert.accept() #aceptar el cuadro de dialogo donde se pregunta si se quiere o no agregar el producto al carrito (confirmación)
    time.sleep(3)
    driver.find_element(By.ID, "nava").click() #volver al inicio dando click en el logo
    time.sleep(3)
    #prod2 - mismo caso que prod1
    driver.find_element(By.LINK_TEXT, "Sony xperia z5").click()
    time.sleep(3)
    driver.find_element(By.LINK_TEXT, "Add to cart").click()
    time.sleep(3)
    driver.switch_to.alert.accept()
    time.sleep(3)
    driver.find_element(By.ID, "nava").click() #volver al inicio con logo
    time.sleep(3)
    #ver carrito
    driver.find_element(By.ID, "cartur").click()
    time.sleep(3)
    #captura del carrito con los dos elementos
    capturarpantalla(driver,'carrito.png')
    #llenar form final
    driver.find_element(By.XPATH, "//button[contains(text(), 'Place Order')]").click()
    time.sleep(3)
    driver.find_element(By.ID, "name").send_keys("David Paez")
    driver.find_element(By.ID, "country").send_keys("Ecuador")
    driver.find_element(By.ID, "city").send_keys("Quito")
    driver.find_element(By.ID, "card").send_keys("202122232425")
    driver.find_element(By.ID, "month").send_keys("January")
    driver.find_element(By.ID, "year").send_keys("2027")
    #captura del formulario lleno
    capturarpantalla(driver,'formlleno.png')
    driver.find_element(By.XPATH, "//button[contains(text(), 'Purchase')]").click()
    time.sleep(3)

    #paso final
    confirmando = driver.find_element(By.XPATH, "//h2[contains(text(), 'Thank you for your purchase')]").text 
    #captura final
    capturarpantalla(driver,'final.png')
    assert "Thank you for your purchase!" in confirmando #verificar mensaje de confirmación final

    #reporte
    reportedir= os.path.join(diractual,'reporte.txt')
    with open(reportedir,'w', encoding="utf-8") as reporte:
        reporte.write("Reporte Final de la Compra\n")
        reporte.write("========================\n\n")
        reporte.write("La prueba se completó con sus respectivas capturas de pantalla\n")
        reporte.write("Por favor, verificar en la carpeta capturasreporte\n")


finally:
    #cerrar navegador
    driver.quit()
    