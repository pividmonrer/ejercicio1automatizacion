###########INSTRUCCIONES DE EJECUCIÓN###########
Paso previo:
Asegurarse de tener instalado Chrome
Pasos:
1. Instalar Python desde: https://www.python.org/downloads/
2. Instalar Selenium mediante el comando: pip install selenium
3. Instalar WebDriver Manager mediante el comando: pip install selenium webdriver-manager (no se usará algo específico como ChromeDriver) debido a distintos factores como tener que escoger la versión exacta del navegador y eso puede ser algo engorroso.
4. Ejecutar el archivo "ejercicio1prueba1" mediante CMD o línea de comandos: sh python ejercicio1prueba1.py

El script abrirá el navegador Chrome, el cual indicará que está controlado por un sistema automático de pruebas.
Posterior a la ejecución completa de la prueba se podrá encontrar una carpeta llamada "capturasreporte" y un archivo de texto llamado "reporte" en el cual se encuentra información de la prueba ejecutada.


Diseñador de la Prueba: Sergio David Páez (como ejercicio para Devsu)